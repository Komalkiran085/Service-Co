package com.example.serviceco;

import android.app.Activity;
import android.os.Bundle;

import com.airbnb.lottie.LottieAnimationView;

public class Splash extends Activity {
    private LottieAnimationView lot;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


    }
}
